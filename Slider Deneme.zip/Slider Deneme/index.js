$(document).ready(function () {
   $('.accordion-item').each(function () {
   console.log($(this));
  //  var accordionItem = $(document).find(".tab-pane").find(".accordion").find(".accordion-item");
   var accordionItemId = $(this).attr("id");
   var navName = accordionItemId.split("-")[2];
   console.log(navName);
   var idx = accordionItemId[accordionItemId.length-1];
   
   console.log(idx);
   var fullName = "-" + navName + "-" + idx;
   
   var tableId = "example" + fullName;
 
   // Function to handle filtering logic
   function customFilterFunction(settings, data, dataIndex) {
     var intVal = function (i) {
       return typeof i === 'string' ?
         i.replace(/[\$,]/g, '')*1 :
         typeof i === 'number' ?
           i : 0;
     };

     var minAge = parseInt($('#minAge' + fullName).val(), 10);
     var maxAge = parseInt($('#maxAge' + fullName).val(), 10);
     var age = parseFloat(data[3]) || 0; // use data for the age column
     var ageFound = false;  // Is the age within the range

     if ((isNaN(minAge) && isNaN(maxAge)) ||
       (isNaN(minAge) && age <= maxAge) ||
       (minAge <= age && isNaN(maxAge)) ||
       (minAge <= age && age <= maxAge)) {
       ageFound = true;
     }

     // Show row if all are within range (all are true) otherwise hide row
     return ageFound;
   }

   var table = $("#" + tableId).DataTable({
     // Pass the custom filter function to DataTable's search configuration
     "search": {
       "search": customFilterFunction
     }
   });
 
   // Ion Range Slider
   var $inputFromAge = $(".inputFromAge"+ fullName),
       $inputToAge = $(".inputToAge"+ fullName);
 
   $(".rangeAge"+ fullName).ionRangeSlider({
     type: "double", min: 10, max: 70,
     skin: "big",
     grid: true,
     grid_num: 10,
     onStart: updateInputs,
     onChange: updateInputs,
     onFinish: updateInputs
   });
   $(".rangeAge"+ fullName).data("ionRangeSlider");
 
   $inputFromAge.on("input", function () {
     var val = $(this).prop("value");
     var slider = $(".rangeAge"+ fullName).data("ionRangeSlider");
     if (val < slider.options.min) { val = slider.options.min; }
     else if (val > slider.options.to) { val = slider.options.to; }
     slider.update({ from: val });
   });
 
   $inputToAge.on("input", function () {
     var val = $(this).prop("value");
     var slider = $(".rangeAge"+ fullName).data("ionRangeSlider");
     if (val < slider.options.from) { val = slider.options.from; }
     else if (val > slider.options.max) { val = slider.options.max; }
     slider.update({ to: val });
   });
 
 
 
 
 
   function updateInputs(data) {
     from = data.from;
     to = data.to;
     rangeInput = $(data.input);
     
     if(rangeInput.hasClass('rangeAge'+ fullName)){
       $inputFromAge.prop("value", from);
       $inputToAge.prop("value", to);
     }
     table.draw();
   }
 
   // Event listener to the two range filtering inputs to redraw on input
   $('#minAge' + fullName + ', #maxAge' + fullName).keyup( function() {
     table.draw();
   });
   

  });
});